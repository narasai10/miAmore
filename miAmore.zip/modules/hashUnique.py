from uuid import uuid4

def createHash():
    return str(uuid4())

