import firebase_admin
from firebase_admin import credentials, db

cred = credentials.Certificate("./dataKey/miamore-30134-firebase-adminsdk-6cnnp-963bf84683.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://miamore-30134-default-rtdb.firebaseio.com/"
})

def createOrder(nameOrder:str, content:str, background:str, name:str):
    ref = db.reference("/order")
    ref.set({
        f"{nameOrder}":{
                "name": name,
                "content": content,
                "background": background,
            }
        }
    )