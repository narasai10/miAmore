function getParamsByName(paraName, url = window.location.href) {
    paraName = paraName.replace(/[\[\]]/g, '\\$&');
    let regex = new RegExp('[?&]' + paraName + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
document.addEventListener("DOMContentLoaded", function () {
    const coupleName = getParamsByName('coupleName');
    if (coupleName) {
        document.getElementById('coupleName').textContent = coupleName;
    }
});

