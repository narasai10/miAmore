from flask import Flask, redirect, url_for, request, render_template, jsonify
from flask_bootstrap import Bootstrap5
import stripe
import stripe.error
from modules.database import *
from modules.hashUnique import createHash

stripe.api_key = 'sk_test_51Pk9Ei05QFJxwTtD4lx9UkZmXPvVl7KbyfkpsXoFCkuJttwKJLo4GHOWu4qMLyq03XNb7qQDxd6fpKb54nnDuyI100DmlrLaYl'
# whsec_2e4bfc5b5329f7b245b26c0bb8bc6d8b1d06aec6dcfae9ac08b5f4a6eec5bd9c
app = Flask(__name__)
bootstrap = Bootstrap5(app)


coupleName = None
coupleContent =  None
coupleBackground = None


@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    global coupleContent
    global coupleBackground

    if request.method == "POST":
        print("Entrou no IF")
        coupleContent = request.form.get("message")
        coupleBackground = request.form.get("bgColor")
        print(coupleContent)
        print(coupleBackground, end="\n")
        print(coupleName)


    
    try:
        checkout_session = stripe.checkout.Session.create(
            line_items=[{
                'price_data': {
                    'currency': 'brl',
                    'product_data': {
                        'name': 'Exemplo',
                    },
                    'unit_amount': 3500,  # preço em centavos (2000 centavos = 20 dólares)
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url='http://localhost:5000/success',
            cancel_url='http://localhost:5000/cancel',
        )

    except Exception as e:
        return str(e)

    return redirect(checkout_session.url, code=303)


@app.route("/webhook", methods=["POST"])
def webhook():
    endpoint_secret = "whsec_2e4bfc5b5329f7b245b26c0bb8bc6d8b1d06aec6dcfae9ac08b5f4a6eec5bd9c"
    event = None
    payload = request.data
    sig_header = request.headers["STRIPE_SIGNATURE"]

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
    except ValueError as e:
        # Invalid payload
        raise e
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        raise e

    # Handle the event
    if event['type'] == 'checkout.session.completed':
      invoice = event['data']['object']
      createOrder(createHash(), content=coupleContent, background=coupleBackground, name=coupleName)
      print(f"content: {coupleContent}\nbackground: {coupleBackground}\nname: {coupleName}")
    else:
      print('Unhandled event type {}'.format(event['type']))

    return jsonify(success=True)


@app.route("/", methods=["POST", "GET"])
def index():
    global coupleName
    if request.method == "POST":
        coupleName = request.form["couple"]
        print(coupleName)
        return redirect(url_for("create", coupleName=coupleName))
    return render_template("index.html", bootstrap=bootstrap)

@app.route("/create", methods=["POST", "GET"])
def create():
    coupleName = request.args.get("coupleName")


    # if request.args.get("coupleName") == None or request.args.get("coupleName").strip() == "":
    #     return render_template("index.html")
    # else:
    return render_template("create.html", bootstrap=bootstrap)

@app.route("/couple/<orderId>")
def couple(orderId):
    return render_template("couple.html", orderId=orderId, bootstrap=bootstrap)

if __name__ == "__main__":
    app.run(debug=True)